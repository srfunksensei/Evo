package eclipse.commandline;

import gr.uom.java.ast.Standalone;
import gr.uom.java.distance.ExtractClassCandidateGroup;
import gr.uom.java.distance.ExtractClassCandidateRefactoring;
import gr.uom.java.distance.MoveMethodCandidateRefactoring;
import gr.uom.java.jdeodorant.refactoring.manipulators.ASTSlice;
import gr.uom.java.jdeodorant.refactoring.manipulators.ASTSliceGroup;
import gr.uom.java.jdeodorant.refactoring.manipulators.TypeCheckElimination;
import gr.uom.java.jdeodorant.refactoring.manipulators.TypeCheckEliminationGroup;

import java.io.File;
import java.net.URI;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.eclipse.core.internal.resources.ProjectDescription;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.equinox.app.IApplication;
import org.eclipse.equinox.app.IApplicationContext;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;

public class Application implements IApplication {

	@Override
	public Object start(IApplicationContext arg0) throws Exception {
		IWorkspace workspace = ResourcesPlugin.getWorkspace();
		IWorkspaceRoot root = workspace.getRoot();
		/*IPath rootPath = root.getLocation();
		File rootFile = rootPath.toFile();
		File[] contents = rootFile.listFiles();
		
		for(File file : contents) {
			if(file.isDirectory() && !file.getName().startsWith(".")) {
				String[] dirContents = file.list();
				List<String> dirContentsList = Arrays.asList(dirContents);
				if(dirContentsList.contains(".project")) {
					IProjectDescription description = ResourcesPlugin.getWorkspace().loadProjectDescription(new Path(file.getPath() + "/.project"));
					IProject project = ResourcesPlugin.getWorkspace().getRoot().getProject(description.getName());
					if(!project.exists()) {
						project.create(null);
					}
					else {
						project.refreshLocal(IResource.DEPTH_INFINITE, null);
					}
					if (!project.isOpen()) {
						project.open(null);
					}
					if(project.hasNature(JavaCore.NATURE_ID)) {
						IJavaProject jproject = JavaCore.create(project);
						if(!jproject.hasBuildState()) {
							project.build(IncrementalProjectBuilder.INCREMENTAL_BUILD, null);
							System.out.println("Project " + project.getName() + " built");
						}
					}
				}
			}
		}

		workspace.save(true, null);*/
		IProject[] projects = root.getProjects();
		for(IProject project : projects) {
			System.out.println(project.getName());
			if(project.hasNature(JavaCore.NATURE_ID)) {
				IJavaProject jproject = JavaCore.create(project);
				List<MoveMethodCandidateRefactoring> moveMethodCandidateList = Standalone.getMoveMethodRefactoringOpportunities(jproject);
				System.out.println("Move Method Refactoring Opportunities:");
				for(MoveMethodCandidateRefactoring candidate : moveMethodCandidateList) {
					System.out.println(candidate);
				}
				
				Set<TypeCheckEliminationGroup> typeCheckEliminationGroupList = Standalone.getTypeCheckEliminationRefactoringOpportunities(jproject);
				System.out.println("Type Check Elimination Refactoring Opportunities:");
				for(TypeCheckEliminationGroup group : typeCheckEliminationGroupList) {
					List<TypeCheckElimination> typeCheckEliminationList = group.getCandidates();
					for(TypeCheckElimination elimination : typeCheckEliminationList) {
						System.out.println(elimination);
					}
				}
				
				Set<ASTSliceGroup> sliceGroupList = Standalone.getExtractMethodRefactoringOpportunities(jproject);
				System.out.println("Extract Method Refactoring Opportunities:");
				for(ASTSliceGroup group : sliceGroupList) {
					Set<ASTSlice> slices = group.getCandidates();
					for(ASTSlice slice : slices) {
						System.out.println(slice);
					}
				}
				
				Set<ExtractClassCandidateGroup> extractClassGroupList = Standalone.getExtractClassRefactoringOpportunities(jproject);
				System.out.println("Extract Class Refactoring Opportunities:");
				for(ExtractClassCandidateGroup group : extractClassGroupList) {
					List<ExtractClassCandidateRefactoring> candidates = group.getCandidates();
					for(ExtractClassCandidateRefactoring candidate : candidates) {
						System.out.println(candidate);
					}
				}
			}
		}
		return IApplication.EXIT_OK;
	}

	@Override
	public void stop() {

	}

}
